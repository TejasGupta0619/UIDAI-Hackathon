const csvToJson = require("convert-csv-to-json");
const fs = require("fs");

// Step 1: Convert CSV to JSON array
const jsonArray = csvToJson
  .fieldDelimiter(",")
  .getJsonFromCsv("postal_code_data.csv");

// Step 2: Group by pincode
const groupedByPincode = jsonArray.reduce((acc, item) => {
  const pincode = item.pincode;

  // Ensure pincode key exists
  if (!acc[pincode]) {
    acc[pincode] = [];
  }

  acc[pincode].push({
    circlename: item.circlename,
    regionname: item.regionname,
    divisionname: item.divisionname,
    officename: item.officename,
    pincode: Number(item.pincode),
    officetype: item.officetype,
    delivery: item.delivery,
    district: item.district,
    statename: item.statename,
    latitude: item.latitude,
    longitude: item.longitude,
  });

  return acc;
}, {});

// Step 3: Match your required output format
const finalOutput = Object.keys(groupedByPincode).map((pincode) => ({
  [pincode]: groupedByPincode[pincode],
}));

// Step 4: Write to file
fs.writeFileSync("pincode.json", JSON.stringify(finalOutput, null, 2));

console.log("CSV successfully converted to keyed JSON!");
